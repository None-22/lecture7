﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sara_hageb_lect4
{
    public partial class Form2 : Form
    {
        string[] a;
        int m = 0, i = 0;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox2.Enabled = button1.Enabled = button4.Enabled
                = button3.Enabled = listBox1.Enabled = textBox3.Enabled = false;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 48 || e.KeyChar > 57)
                e.Handled = true;
            if (e.KeyChar == 8)
                e.Handled = false;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 48 || e.KeyChar > 57)
                e.Handled = true;
            if (e.KeyChar == 8)
                e.Handled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            if (i > 0)
            {
                for (int h = 0; h < i; h++)
                    listBox1.Items.Add(a[h]);
            }
            else
                MessageBox.Show("المصفوفه فارغه");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int s = 0;
            if (listBox1.Items.Count > 0)
            {
                for (int h = 0; h < i; h++)
                    s += int.Parse(a[h]);
                textBox3.Text = s.ToString();
            }
            else
                MessageBox.Show("القائمه فارغه");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            bool f = (textBox1.Text != "");
            textBox2.Enabled = button1.Enabled = button4.Enabled = button3.Enabled = listBox1.Enabled = textBox3.Enabled = f;
            listBox1.Items.Clear();
            textBox3.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int b = listBox1.Items.Count;
            if (b > 0)
            {
                for (int h = 1; h <= b; h++)
                    listBox1.Items.Remove(listBox1.Items[0]);
                i = m = 0;
                a = new string[0];
                textBox2.Text = textBox1.Text = textBox3.Text = " ";
                Form2_Load(null, null);

            }
            else
                MessageBox.Show("القائمه فارغه");

        }

        private void textBox1_LocationChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "")
            {
                m = int.Parse(textBox1.Text);
                a = new string[m];
                i = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text.Trim() != "")
            {
                if (i < m)
                {
                    a[i++] = textBox2.Text.ToString();
                    textBox2.Focus();
                    textBox2.Clear();
                }
                else
                {
                    MessageBox.Show("تجاوزت حجم المصفوفه");
                    textBox2.Clear();
                }


            }
            else
            { MessageBox.Show("ادخل الرقم"); }
        }
    }
}
