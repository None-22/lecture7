﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace sara_hageb_lect4
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (radioButtonup.Checked)
                for (int i = 0; i < Top; i++)
                {
                    // MessageBox.Show("Test");
                    if (checkBox1.Checked)
                        button10.Top -= Convert.ToInt16(checkBox1.Text);
                    else if (checkBox2.Checked)
                        button10.Top -= Convert.ToInt32(checkBox2.Text);
                    else if (checkBox4.Checked)
                        button10.Top -= Convert.ToInt32(checkBox4.Text);
                    else if (checkBox5.Checked)
                        button10.Top -= Convert.ToInt32(checkBox5.Text);
                    for (int j = 0; j < 100000000; j++) ;

                }
            else
if (radioButtondown.Checked)
                for (int i = 0; i < Top; i++)
                {
                    if (checkBox1.Checked)
                        button10.Top += Convert.ToInt32(checkBox1.Text);
                    else if (checkBox2.Checked)
                        button10.Top += Convert.ToInt32(checkBox2.Text);
                    else if (checkBox4.Checked)
                        button10.Top += Convert.ToInt32(checkBox4.Text);
                    else if (checkBox5.Checked)
                        button10.Top += Convert.ToInt32(checkBox5.Text);
                    for (int j = 0; j < 100000000; j++) ;
                }


        }

        private void button6_Click(object sender, EventArgs e)
        {
            button10.Location = new Point(button10.Left, button10.Top + 5);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button10.Size = new Size(button10.Width, button10.Height + 5);
          

        }

        private void button2_Click(object sender, EventArgs e)
        {
            button10.Size = new Size(button10.Width, button10.Height - 5);
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
           button10.Width -= 5;
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button10.Width += 5;
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button10.Top -= 5;

        }

        private void button8_Click(object sender, EventArgs e)
        {
            button10.Location = new Point(button10.Left + 5, button10.Top);

        }

        private void button7_Click(object sender, EventArgs e)
        {
           button10.Location = new Point(button10.Left - 5, button10.Top);
        }
    }
}
