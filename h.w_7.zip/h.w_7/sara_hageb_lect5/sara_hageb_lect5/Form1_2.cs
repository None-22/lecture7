﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara_hageb_lect5
{
    public partial class Form1_2 : Form
    {
        public Form1_2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                label1.BackColor = Color.Red;
            else if (radioButton2.Checked)
                label1.BackColor = Color.Blue;
            else if (radioButton3.Checked)
                label1.BackColor = Color.Green;
            else if (radioButton4.Checked)
                label1.BackColor = Color.Yellow;


            if (radioButton5.Checked)
                label1.ForeColor = Color.Black;
            else if (radioButton6.Checked)
                label1.ForeColor = Color.Yellow;
            else if (radioButton7.Checked)
                label1.ForeColor = Color.Red;
            else if (radioButton8.Checked)
                label1.ForeColor = Color.Green;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int s = 0; bool f = false;
            textBox1.Text = null;
            if (checkBox1.Checked == true)/*if (checkBox1. Checked)*/{ s += Convert.ToInt32(checkBox1.Text); f = true; }
            if (checkBox2.Checked) { s += Convert.ToInt32(checkBox2.Text); f = true; }
            if (checkBox3.Checked) { s += Convert.ToInt32(checkBox3.Text); f = true; }
            if (checkBox4.Checked) { s += Convert.ToInt32(checkBox4.Text); f = true; }
            if (checkBox5.Checked) { s += Convert.ToInt32(checkBox5.Text); f = true; }
            if (f)
                textBox1.Text = s.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(panel1.Enabled)
            {
                panel1.Enabled = false;
                button3.Text = "Enabled";
            }
            else
            {
                panel1.Enabled = true;
                button3.Text = "Unenabled";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (panel1.Visible)
            {
                panel1.Visible = false;
                button4.Text = "Visible";
            }
            else
            {
                panel1.Visible = true;
                button4.Text = "Unvisible";
            }
        }
    }
}
