﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara_hageb_lect5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        Thread threadgo;
        void go()
        {
            for (int i = 0; i <= this.Width; i++)
            {
                Invoke((Action)(() =>
                {
                    button1.Left += 10;
                }));
                if (button1.Left > this.Width - button1.Width - 50)
                {
                    break;
                }
                System.Threading.Thread.Sleep(100);
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = button2.Top; i <= this.Height - button2.Height - 70; i++)
            {
                if (button2.Top > this.Height - button2.Height - 70)
                {
                    break;
                }
                button2.Top += 10;
                System.Threading.Thread.Sleep(100);
                Application.DoEvents();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            threadgo = new Thread(go);
            threadgo.Start();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (threadgo != null)
                threadgo.Abort();
        }
    }
}
