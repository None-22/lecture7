﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara_hageb_lect5
{
    public partial class Form2_2 : Form
    {
        public Form2_2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Top -= 10;
            button3.Top -= 10;
            button4.Top -= 10;
            button5.Top -= 10;
            button6.Top -= 10;
            button7.Top -= 10;
            button8.Top -= 10;
            button9.Top -= 10;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button2.Top += 10;
            button3.Top += 10;
            button4.Top += 10;
            button5.Top += 10;
            button6.Top += 10;
            button7.Top += 10;
            button8.Top += 10;
            button9.Top += 10;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button2.Left += 10;
            button3.Left += 10;
            button4.Left += 10;
            button5.Left += 10;
            button6.Left += 10;
            button7.Left += 10;
            button8.Left += 10;
            button9.Left += 10;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button2.Left -= 10;
            button3.Left -= 10;
            button4.Left -= 10;
            button5.Left -= 10;
            button6.Left -= 10;
            button7.Left -= 10;
            button8.Left -= 10;
            button9.Left -= 10;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button2.Height += 10;
            button3.Height += 10;
            button4.Height += 10;
            button5.Height += 10;
            button6.Height += 10;
            button7.Height += 10;
            button8.Height += 10;
            button9.Height += 10;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button2.Height -= 10;
            button3.Height -= 10;
            button4.Height -= 10;
            button5.Height -= 10;
            button6.Height -= 10;
            button7.Height -= 10;
            button8.Height -= 10;
            button9.Height -= 10;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button2.Width += 10;
            button3.Width += 10;
            button4.Width += 10;
            button5.Width += 10;
            button6.Width += 10;
            button7.Width += 10;
            button8.Width += 10;
            button9.Width += 10;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button2.Width -= 10;
            button3.Width -= 10;
            button4.Width -= 10;
            button5.Width -= 10;
            button6.Width -= 10;
            button7.Width -= 10;
            button8.Width -= 10;
            button9.Width -= 10;
        }
    }
}
