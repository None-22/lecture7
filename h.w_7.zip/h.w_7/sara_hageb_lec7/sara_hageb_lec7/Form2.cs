﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

namespace sara_hageb_lec7
{
    public partial class Form2 : Form
    {
        public static string s = "";
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(string name)
        {
            InitializeComponent();
            this.Text = name;
        }
        Form3 objf3;

        public Form2(Form3 objectform3)
        {
            InitializeComponent();
            textBox2.Text = objectform3.getname();
            textBox2.Text = objectform3.textBox3.Text;
            objf3 = objectform3;
        }
        public Form2(ListBox mylist)
        {
            InitializeComponent();
            listBox1 = mylist;
        }
        public void setvalue(string name)
        {
            textBox2.Text = name;
        }
        public string getvalue()
        {
            return textBox2.Text;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox2.Text);
        }
       

        private void button2_Click(object sender, EventArgs e)
        {
            objf3.updatename(getvalue());
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_ModifiedChanged(object sender, EventArgs e)
        { }


    }
}
