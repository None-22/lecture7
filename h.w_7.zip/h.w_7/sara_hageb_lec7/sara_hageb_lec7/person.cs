﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace sara_hageb_lec7
{
    internal class person
    {
        String firstname;
        public String lastname;
        public void setfirstname(String f)
        {
          firstname = f;
           
        }
        public string getfirstname=>firstname;


    }
}
