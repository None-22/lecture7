﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara_hageb_lec7
{

    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        public string getname()
        {
            return textBox3.Text;
        }
        public void updatename(string name)
        { 
            textBox3.Text = name; 
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form2 f = new Form2(listBox1);
            f.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form2 f = new Form2("التعامل مع الواجهات المتعددة");
            f.ShowDialog();
            f.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form2 f = new Form2(this);
            f.Show();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.setvalue(textBox3.Text);
            f.Show();
        }
        Form2 fonce = new Form2();
        private void button6_Click_1(object sender, EventArgs e)
        {
            fonce.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.textBox2.Text = textBox3.Text;
            f.Show();
        }
        Form2 formalobj;
        private void button8_Click_1(object sender, EventArgs e)
        {
            if (formalobj == null || formalobj.IsDisposed)
            {
                formalobj = new Form2();
                formalobj.Show();
            }
            else
            {
                formalobj.Show();
            }
        }
        private void button9_Click_1(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            Form2.s = textBox3.Text;
            f.Show();
        }


        private void button10_Click_1(object sender, EventArgs e)
        {
            new Form2(textBox3.Text).Show();
        }
        private void button11_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
