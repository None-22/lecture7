﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara_hageb_lec7
{
    public partial class Form4 : Form
    {
        Formadd a;
        Formsub s;
        Formmulti m;
        Formdiv d;
        public Form4()
        {
            InitializeComponent();
        }

        private void جمعToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (a == null || a.IsDisposed)
            {
                a = new Formadd();
                a.Show();
            }
            else
            { 
                a.Show();
            }
        }

        private void طرحToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (s == null || s.IsDisposed)
            {
                s = new Formsub();
                s.Show();
            }
            else
            { 
                s.Show();
            }
        }

        private void ضربToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (m == null || m.IsDisposed)
            {
                m = new Formmulti();
                m.Show();
            }
            else
            { 
                m.Show();
            }
        }

        private void قسمهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (d == null || d.IsDisposed)
            {
                d = new Formdiv();
                d.Show();
            }
            else
            { 
                d.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (a == null || a.IsDisposed)
            {
                a = new Formadd();
                a.Show();
            }
            else
            { 
                a.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (s == null || s.IsDisposed)
            {
                s = new Formsub();
                s.Show();
            }
            else
            { s.Show(); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (m == null || m.IsDisposed)
            {
                m = new Formmulti();
                m.Show();
            }
            else
            {
                m.Show();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (d == null || d.IsDisposed)
            {
                d = new Formdiv();
                d.Show();
            }
            else
            {
                d.Show();
            }
        }
    }
}
