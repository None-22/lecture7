﻿using System.Windows.Forms;

namespace sara_hageb_lec7
{
    internal class studnet : person
    {
        int id;
        public string name;
        static string gender;
        public static string addr;
        public person p = new person();// سيتم تعليقها بالوراثة
        

        public studnet()//عشان الوراثة رجعته بابلك
        { 
            id = 0;
            name = "";
            gender = "";
            addr = "";
        }
       
        public studnet(int id, string name, string g)
        {
            this.id = id;
            this.name = name;
            gender = g;
            MessageBox.Show(id.ToString() + "  " + name + "  " + gender);
        }
        private void setid(int id)
        {
            this.id = id;
        }
        public void setname(string name)
        {
            this.name = name;
        }
        public int getid()
        {
            return id;
        }
        public string getname()
        {
            return name;
        }
        public string getgender() => gender;
        public static void setadd(string add)
        {
            addr = add;
        }
        private static string getadd()
        {
            return addr;
        }

        //--------------------------------
        // !!!!!!!!!!!!! سيتم تعليق هذوا بالوراثة!!!!!!!!!!!!!!!!
        public void setfirstlastname(string f, string l)
        {
            p.setfirstname(f);
            p.lastname = l;
        }
        public string getfirstlastname()
        {
            return p.getfirstname + " " + p.lastname;
        }
    }
}

