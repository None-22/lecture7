﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara_hageb_lec7
{


    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ////هذا حق فورم ون وبسوي تعليق للابلكيشن الثاني 
            //Form1 f1 = new Form1("add", "insert item");
            //MessageBox.Show(f1.getbtmtext());
            //f1.disgin();
            //f1.visual();
            //f1.Show();
            //Form1 f2 = new Form1();
            //f2.set("اضافه", "ادخل العنصر");
            //f2.disgin();
            //f2.visual();
            //f2.Show();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form4());




            //studnet s = new studnet(1, "sara", "female");
            //int id = s.getid();
            //MessageBox.Show(id.ToString());
            //s.setname("Ahmed");//تتنفذ لما احول الدالة بابلك
            //string name = s.getname();
            //MessageBox.Show(name);

            ////-----------------------------------

            //MessageBox.Show(new studnet(2, "Omar", "male").getid().ToString());
            //studnet s2 = new studnet(3, "Aouf", "male");
            //MessageBox.Show(s.getid().ToString());
            //MessageBox.Show(s2.getid().ToString());

            ////-----------------------------------

            //studnet.setadd("Ibb");
            //MessageBox.Show(studnet.addr);
            //studnet.setadd("Sana'a");
            //MessageBox.Show(studnet.addr);

            ////-----------------------------------

            //studnet s3 = new studnet(4, "Adnan", "male");
            //s3.setfirstlastname("sara", "hageb");
            //MessageBox.Show(s3.getfirstlastname());

            ////-----------------------------------

            //s3.p.lastname = "Hageb";
            //s3.p.setfirstname("Sara");
            //MessageBox.Show(s3.p.getfirstname);

            ////-----------------------تنفيذ البيرسون

            //person p = new person();
            //p.lastname = "Abdullah Hageb";
            //p.setfirstname("Hesham Ahmed");
            //MessageBox.Show(p.getfirstname + " " + p.lastname);

            ////------------------------تنفيذ الوراثة

            //studnet s4 = new studnet();
            //s4.lastname = "HAGEB";
            //MessageBox.Show(s4.lastname);
            //s4.setfirstname("AMR");
            //MessageBox.Show(s4.getfirstname);

        }
    }
}
